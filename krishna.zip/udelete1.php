  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
     <script type="text/javascript">

    function PrintElem(elem)
    {
        Popup($(elem).html());
    }

    function Popup(data) 
    {
        var mywindow = window.open('', 'my div', 'height=400,width=600');
        mywindow.document.write('<html><head><title>INFOSSEL Software</title>');
        /*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
        mywindow.document.write(' <h1 style="color:green;text-align:center;" >INFOSSEL Software</h1><body >');
        mywindow.document.write(data);
        mywindow.document.write('<h3 style="text-align:right;">Signed by</h3><h3 style="color:blue;text-align:right;">For INFOSSEL Software</h3></body></html>');

        mywindow.print();
        mywindow.close();

        return true;
    }

</script>
     
	<?php $hpl=$_REQUEST['hpl'];?>
     <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h4>
                       Customer Details Deletion &nbsp;&nbsp;
                       <button type="submit"><a href="view1.php">View</a></button>&nbsp;&nbsp;&nbsp;&nbsp;
	    <button type="submit"><a href="customer.php">Add</a></button>&nbsp;&nbsp;&nbsp;&nbsp;
  <button type="submit"><a href="update1.php">Update</a></button>
 
  </br></br>
                       
                    </h4>
                 
                </section>

                <!-- Main content -->
                <section class="content">


                    <!-- top row -->
                    <div class="row">
                        <div class="col-xs-12 connectedSortable">
                            
                        </div><!-- /.col -->
                    </div>
                    <!-- /.row -->
	
                    <!-- Main row -->
                             <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                            
        <div id="mydiv">
  <input type="button" value="Print" onclick="PrintElem('#mydiv')"  style="margin:20px;">
  
                    <form name="form1" method="post" action="" enctype="multipart/form-data">
						<?php
						$qry=mysql_query("select * from customerdetails where hpl='$hpl'");
						?>
					<?php 
					$row=mysql_fetch_array($qry)
					?>
					<table class="table table-striped" >
					<col width="150px">
					<tbody style="color:#FF0080;background:white;">
					<tr>
						<td style="background-color:#FFAAAA;">Registration Date</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['hpdate'];?></td>
						</tr>
      					<tr>
						<td style="background-color:#FFAAAA;">Hpl</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['hpl'];?></td>
						</tr>
							<tr>
						<td style="background-color:#FFAAAA;">Name</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['name'];?></td>
						</tr>
							<tr>
						<td style="background-color:#FFAAAA;">Mobile No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['pno'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Address</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['address'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Delete</td>						
						<td style="background-color:#FFD4FF;"><button type="submit" class="btn btn-default" name="s1">Delete</button></td>
						</tr>
						
							<div class="alert alert-warning">
							<?php
							if(isset($_POST['s1']))
							{
								extract($_POST);
								$qry=mysql_query("select * from customerdetails where hpl='$hpl'");
								$n=mysql_num_rows($qry);
								if($n==0)
									{
										echo"Already Deleted";
									}
								else		
									{
										$delete=mysql_query("delete from customerdetails where hpl='$hpl'");
										if($delete)
										{
										echo"Deleted";
										}
										else
										{
										echo "Try Again";
										}
									}
							}			
							
						   
								
?>							</div>										
					</tbody>
					<?php
					
				
			?>			
					</table>
					</form>
</div>
</div></div>
</div></div></div></div></section>
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="js/AdminLTE/app.js" type="text/javascript"></script>

    </body>
</html>