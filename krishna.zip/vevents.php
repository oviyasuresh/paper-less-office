  <?php include "layouts/menu.php"; ?>
		
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
  <script>
	function autocomplet() {
	var min_length = 0; // min caracters to display the autocomplete
	var keyword = $('#did').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'ajax_refresh.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#country_list_id').show();
				$('#country_list_id').html(data);
			}
		});
	} else {
		$('#country_list_id').hide();
	}
}

// set_item : this function will be executed when we select an item
function set_item(item) {
	// change input value
	$('#did').val(item);
	// hide proposition list
	$('#country_list_id').hide();
}
	</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script type="text/javascript">
function CollapseForm()
{
// Two places to customize:

// Specify the id of the form.
var IDofForm = "form1";

// Specify the id of the div containing the form.
var IDofDivWithForm = "demo";

// This line submits the form. (If Ajax processed, call Ajax function, instead.)
document.getElementById(IDofForm).submit();

// This line collapses the form.
document.getElementById(IDofDivWithForm).style.display = "none";
}
</script>
     
    <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
       	
				
                    <?php
					
						$qry=mysql_query("select * from event");
						$n=mysql_num_rows($qry);
						if($n==0)
						{
							echo "Nothing To Display";
						}
						else
						
					{ 
						?>
                <!-- Main content -->
               <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>soldier <small>Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                       </p>
                    <table id="datatable-buttons" id="datatable-buttons" class="table table-striped table-bordered">
                                        <thead>
		<tr><th>Start_Date</th>
<th>End_Date</th>

<th>Event Name</th>
<th>Description</th>
<th>RefLink</th>

</tr>
                                        </thead>
									<tbody>	<?php $tg = 0;
					while($row2=mysql_fetch_array($qry))
						{ $tg++;
					?>
                             <tr><td><?php echo $row2['Start_Date']; ?></td>
<td><?php echo $row2['End_Date']; ?></td>

<td><?php echo $row2['Event_Name']; ?></td>
<td><?php echo $row2['Description']; ?></td>
<td><?php echo $row2['RefLink']; ?></td>

 </tr>
                                          
                                        <?php
						}
					}
				
					?></tbody>
					                    
                                    </table>		
                               </div></div> <!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

              

        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>