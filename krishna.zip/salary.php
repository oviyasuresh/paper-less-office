
		
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script>
function add()
{
var x = document.getElementById("txt1").value;
var y = document.getElementById("txt2").value;
document.getElementById("bal").value =(x*1)-(y*1);
}
</script>
    </head>
  <?php include "layouts/menu.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                      Soldiers Salary Details
                      
                    </h1>
                   
                </section>
                   <div class="panel-body">
                            <div class="row">
   <div class="alert alert-info">Register Soldiers Salary Details</div><a href="addcats.php">Add Catogory</a>
   <form name="form1" class="form-horizontal" method="post" action="salary.php" enctype="multipart/form-data">
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Basic Pay</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="debit" value="" placeholder="Amount in Rs" required>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">LTA</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="lta" value="" placeholder="Amount in Rs" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">HRA</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="hra" value="" placeholder="Percentage" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Medical</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="medical" value="" placeholder="Amount in Rs" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Conveyance </label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="conveyance" value="" placeholder="Amount in Rs" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Special Allowance</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="spa" value="" placeholder="Amount in Rs" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Total</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="tot" value="" placeholder="Amount in Rs" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Pension</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="pension" value="" placeholder="Pension" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Soldier Id</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="sol" value="" placeholder="Solder id" required>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Account Number</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="noo" value="" placeholder="Account No" required>
    </div>
  </div>
	   
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default" name="s1">Save This</button>
    </div>
  </div>
      <div class="alert alert-success">
	 <?php
							if(isset($_POST['s1']))
							{
								extract($_POST);
								$insert=mysql_query("insert into `salary`(`Basic Pay`,`LTA`,`HRA`,`Medical`,`Conveyance`,`Special Allowance`,`Total`,`Pension`,`Soldier_Id`,`Account Number`)
											 values('$debit','$lta','$hra','$medical','$conveyance','$spa','$tot','$pension','$sol','$noo')");
								
								if($insert)
								{
									
									echo "Registered Successfully"; 
							
									
								}
								else
								{
									echo "Failure";
								}
							}
?>
	  </div>
</form>
</div>
 
 
</div>
  		
				
                    <?php
					
						$qry=mysql_query("select * from salary");
						$n=mysql_num_rows($qry);
						if($n==0)
						{
							echo "Nothing To Display";
						}
						else
						
					{ 
						?>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12"> 
                            <div class="box">
                               <!-- /.box-header -->
                                <div class="box-body table-responsive">
                                    <table id="table2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
											<th>Basic Pay</th>
											<th>LTA</th>
											<th>Medical</th>
												<th>Conveyance</th>
												<th>Special Allowance</th>
												<th>Soldier Id</th>
													<th>Account No</th>
												
                                            </tr>
                                        </thead>
										<?php 
					while($row2=mysql_fetch_array($qry))
						{
					?>
                                        <tbody>
                                           <tr>
              						<td><?php echo $row2['Basic Pay']; ?></td>
									<td><?php echo $row2['LTA']; ?></td>
									<td><?php echo $row2['Medical']; ?></td>
									<td><?php echo $row2['Conveyance']; ?></td>
									<td><?php echo $row2['Special Allowance']; ?></td>
									<td><?php echo $row2['Soldier_Id']; ?></td>	
						<td><?php echo $row2['Account Number']; ?></td>
                                            </tr>
                                          </tbody>
                                        <?php
						}
					}
				
					?>
					                    
                                    </table>		
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

                </section><!-- /.content -->
                 </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>