  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
   
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>

		   <script>
	function autocomplet() {
	var min_length = 0; // min caracters to display the autocomplete
	var keyword = $('#did').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'ajax_refreshentry.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#country_list_id').show();
				$('#country_list_id').html(data);
			}
		});
	} else {
		$('#country_list_id').hide();
	}
}

// set_item : this function will be executed when we select an item
function set_item(item) {
	// change input value
	$('#did').val(item);
	// hide proposition list
	$('#country_list_id').hide();
}
	</script>

    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script type="text/javascript">
function CollapseForm()
{
// Two places to customize:

// Specify the id of the form.
var IDofForm = "form1";

// Specify the id of the div containing the form.
var IDofDivWithForm = "demo";

// This line submits the form. (If Ajax processed, call Ajax function, instead.)
document.getElementById(IDofForm).submit();

// This line collapses the form.
document.getElementById(IDofDivWithForm).style.display = "none";
}
</script>
     
    <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
              <section class="content-header">
                    <div class="col-lg-6">  	
   
  <button class="btn btn-success btn-lg" type="submit"><a href="vtask.php">&nbsp;<font color="white">All Task's&nbsp;&nbsp;&nbsp;</font></a></button>&nbsp;&nbsp;&nbsp;&nbsp;
  <button class="btn btn-success btn-lg" type="submit"><a href="alltask.php">&nbsp;<font color="white">All Pending Task&nbsp;&nbsp;&nbsp;</font></a></button>&nbsp;&nbsp;&nbsp;&nbsp;
  <button class="btn btn-success btn-lg" type="submit"><a href="mytask.php">&nbsp;<font color="white">My Pending Task&nbsp;&nbsp;&nbsp;</font></a></button>&nbsp;&nbsp;&nbsp;&nbsp;
  <button class="btn btn-danger btn-lg" type="submit"><a href="task.php"><font color="white">&nbsp;Add&nbsp;&nbsp;&nbsp;</font></a></button>&nbsp;&nbsp;&nbsp;&nbsp;

  </br></br>
</div>
 <div class="pull-right box-tools">
<button class="btn btn-danger btn-sm refresh-btn" data-toggle="tooltip" title="Reload"  ><i class="fa fa-refresh"></i></button>
                                        <button class="btn btn-danger btn-sm" data-widget='collapse' data-toggle="tooltip" title="Collapse" ><i class="fa fa-minus"></i></button>
                                        <button class="btn btn-danger btn-sm" data-widget='remove' data-toggle="tooltip" title="Remove" ><i class="fa fa-times"></i></button>
                                    </div>

                </section>  <a href="add_sales_print.php">Printview</a>
		<div id="col-lg-12">		
 
 
  </div>	
  			
                    <?php
					
						$qry=mysql_query("select * from task ORDER BY edate ASC");
						$n=mysql_num_rows($qry);
						if($n==0)
						{
							echo "Nothing To Display";
						}
						else
						
					{ 
						?>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                  
                        <div class="col-xs-12"> 
          
                            <div class="box">
                               <!-- /.box-header -->
                                <div class="box-body table-responsive">
                                <div id="mydiv">
<input type="button" value="Print" onclick="PrintElem('#mydiv')"  style="margin:20px;"> <div  style="overflow: scroll">
                                    <table id="table2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr class="danger">
                                                <th>S.no</th>
                                                <th>Name</th>
                                                <th colspan="2">E-Date</th>
						<th>Issue Type</th>
						<th>Description</th>
						<th>Assigned to</th>
						<th>Finished By</th>
						<th>0/1</th>
						<th>Remark</th>
						<th>Finish Date</th>
						 <th>Edit(Assign)</th>	
 										</tr>
                                        </thead>
										<?php $tg = 0;
					while($row2=mysql_fetch_array($qry))
						{ $tg++;
					?>
                                        <tbody>
                                           <tr>
                                           <td><?php echo $tg;?></td>
                                               <td><?php echo $row2['cname'];?></td>
						<td colspan="2"><?php echo $row2['edate']; ?></td>
						<td><?php echo $row2['type']; ?></td>
						<td><?php echo $row2['desc']; ?></td>
		
						<td><?php echo $row2['staff'];?></td>
						<td><?php echo $row2['by'];?></td>
						
						<td><?php echo $row2['new'];?></td>
						<td><?php echo $row2['remark'];?></td>
						<td><?php echo $row2['fdate'];?></td>
						<td><a href="utask.php?id=<?php echo $row2['id'];?>">Edit(Assign)</a></td>
					  </tr>
                                          </tbody>
                                        <?php
						}
					}
				
					?>
					                    
                                    </table>		
                                </div>  </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div></div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>