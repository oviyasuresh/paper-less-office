  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script>
function add()
{
var x = document.getElementById("txt1").value;
var y = document.getElementById("txt2").value;
document.getElementById("bal").value =(x*1)-(y*1);
}
</script>
     
  <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                      Change Your Password Here
                      
                    </h1>
                   
                </section>
                   <div class="panel-body">
                            <div class="row">
  <form name="form1" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Enter Your Username</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="inputPassword3" name="uname" value="" placeholder="User Name" required>
    </div>
  </div>
 <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Enter Your New Password</label>
    <div class="col-sm-4">
      <input type="password" class="form-control" id="inputPassword3" name="pwd" value="" placeholder="New Password" required>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default" name="s2">Change it</button>
    </div>
  </div>
      <div class="alert alert-success">
      <?php
							if(isset($_POST['s2']))
							{
								extract($_POST);
								$update=mysql_query("update admin set pwd='$pwd' where uname='$uname'");
								if($update)
								{
									echo "Success";
								}
								else
								{
									echo "Failure";
								}
							}
?>
	  </div>
</form>


 
</div>
  	
                            </div><!-- /.box -->
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>