<?php include "layouts/menu.php"; ?>
		
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
 <script> 
function sum() 
{ 
var z = document.getElementById("tot").value; 
var q = document.getElementById("payment").value; 
document.getElementById("balance").value =((z*1)-(q*1));  
} 
function confirmSubmit(Soldier_Id,table,return)
{ 	     jConfirm('You Want Create Soldier', 'Confirmation Dialog', function (r) {
           if(r){ 
               console.log();
                $.ajax({
  			data: { Soldier_Id: Soldier_Id, table:table,return:return},
  			success: function(data) {
    			window.location ='old-register.php';
    			
                        jAlert('Soldier Is Created', 'POSNIC');
  			}
		});
            }
            return r;
        });
}
</script>

      <div class="right_col" role="main"> 
	  
	  <?php 
	  $qry=mysql_query("Select * From soldier");
	  $n=mysql_num_rows($qry);
	
					?>

                <!-- Content Header (Page header) -->
                    <div class="page-title">
              <div class="title_left">
                <h3>New User Entry</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                  
                    <span class="input-group-btn">
                      <button class="btn btn-primary" type="button"><a href="yview1.php"><font color="white">View!</font></a></button>
					
                      <button class="btn btn-info" type="button"><a href="old-register.php"><font color="white">Add User!</font></a></button>

                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
               <div class="col-md-3 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>User <small>Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
   
<form name="form8" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
<?php 
					while($row2=mysql_fetch_array($qry))
						{
					?>
<div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Soldier_Id</label>
      <input type="text" class="form-control" id="inputPassword3" name="Soldier_Id" value="<?php echo $row2['Soldier_Id'];?>" required>
 
 </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Name</label>
      <input type="text" class="form-control" id="inputPassword3" name="Name" value="<?php echo $row2['Name'];?>" placeholder="name">
 
  </div>
  
  <div class="form-group has-success has-feedback">
    <label for="inputEmail3" >Batch_Number</label>
      <input type="text" class="form-control" id="inputEmail3" name="Batch_Number" value="<?php echo $row2['Batch_Number'];?>" placeholder="">
 
  </div>
  
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Date_Of_Birth</label>
      <input type="text" class="form-control" id="inputPassword3" name="Date_Of_Birth" value="<?php echo $row2['Date_Of_Birth'];?>" placeholder="DD-MM-YYYY">
    
  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Password</label>
      <input type="text" class="form-control" id="inputPassword3" name="Password" value="<?php echo $row2['Password'];?>" placeholder="">
    
  </div>
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Start_Of_Service</label>
      <input type="text" class="form-control" id="inputPassword3" name="Start_Of_Service" value="<?php echo $row2['Start_Of_Service'];?>" placeholder="DD-MM-YYYY">

  </div>
 
                </div>
              </div> </div>
        
	 <div class="col-md-3 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                          <h2>User <small>Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br /> 

   
   
      <input type="hidden" class="form-control" id="inputPassword3" name="Age" value="<?php echo $row2['Age'];?>" placeholder="">


  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" class="control-label">Nationality</label>
      <input type="text" class="form-control" id="datepicker"  name="Nationality" value="<?php echo $row2['Nationality'];?>" placeholder="">

    </div>
 <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Blood_Group</label>
      <input type="text" class="form-control" id="inputPassword3" name="Blood_Group" value="<?php echo $row2['Blood_Group'];?>" placeholder="">
   
  </div>
	 <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Address</label>
      <input type="text" class="form-control" id="inputPassword3" name="Address" value="<?php echo $row2['Address'];?>" placeholder="">

  </div><div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Contact</label>
      <input type="text" class="form-control" id="inputPassword3" name="Contact" value="<?php echo $row2['Contact'];?>" placeholder="">

   
   </div>
  </div>
  
  </div>
                </div>
              
        
	 <div class="col-md-3 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                          <h2>User <small>Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
					
			 <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Designation</label>
      <input type="text" class="form-control" id="inputPassword3" name="Designation" value="<?php echo $row2['Designation'];?>" placeholder="">

  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Qualifications</label>
      <input type="text" class="form-control" id="inputPassword3" name="Qualifications" value="<?php echo $row2['Qualifications'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Years_Of_Experience</label>
      <input type="text" class="form-control" id="inputPassword3" name="Start_Of_Service" value="<?php echo $row2['Years_Of_Experience'];?>" placeholder="">

  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Description</label>
      <input type="text" class="form-control" id="inputPassword3" name="Description" value="<?php echo $row2['Description'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Image</label>
    <input type="file" class="form-control" id="inputPassword3" name="Image" value="<?php echo $row2['Image'];?>" placeholder="">
  </div>		
  
	<div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Voter_Id</label>
     <input type="file" class="form-control" id="inputPassword3" name="Voter_Id" value="<?php echo $row2['Voter_Id'];?>" placeholder="">

  </div>
  
                                     </div>
                </div>
              </div>
			   <div class="col-md-3 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                         <h2>User <small>Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
	
   
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Pan_Id</label>
       <input type="file" class="form-control" id="inputPassword3" name="Pan_Id" value="<?php echo $row2['Pan_Id'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Aadhar_Id</label>
     <input type="file" class="form-control" id="inputPassword3" name="Aadhar_Id" value="<?php echo $row2['Aadhar_Id'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Gender</label>
      <input type="text" class="form-control" id="inputPassword3" name="Gender" value="<?php echo $row2['Gender'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Email_iId</label>
      <input type="text" class="form-control" id="inputPassword3" name="Email_iId" value="<?php echo $row2['Email_iId'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Father_Name</label>
      <input type="text" class="form-control" id="inputPassword3" name="Father_Name" value="<?php echo $row2['Father_Name'];?>" placeholder="">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Mother_Name	</label>
      <input type="text" class="form-control" id="inputPassword3" name="Mother_Name	" value="<?php echo $row2['Mother_Name'];?>" placeholder="">

  </div>
   	
  
<div class="form-group has-success has-feedback">

      <button "javascript:confirmSubmit(<?php echo $row['Soldier_Id'];?>,'soldier','old-register.php')" type="submit"  name="s2" class="btn btn-success btn-lg btn-block">Update</button>

  </div>  
                                     </div>
                </div>	
              </div>
    
	
								 
							
                            <!-- /.box -->
		
                        	

                      	
						
                    </div><!-- /.row (main row) -->
          
       
		  <div>
<?php
							if(isset($_POST['s2']))
							{
								extract($_POST);
								$Image=$_FILES['Image']['name'];
								$voter=$_FILES['Voter_Id']['name'];
								$pan=$_FILES['Pan_Id']['name'];
								$aadhar=$_FILES['Aadhar_Id']['name'];
								$update=mysql_query("update `soldier` set Soldier_Id='$Soldier_Id', Name='$Name', Batch_Number='$Batch_Number',Date_Of_Birth='$Date_Of_Birth',Password='$Password',Start_Of_Service='$Start_Of_Service',Nationality='$Nationality',Blood_Group='$Blood_Group', Address='$Address',Contact='$Contact',Designation='$Designation',Qualifications='$Qualifications',Years_Of_Experience='$Years_Of_Experience',Description='$Description',Image='$Image',Voter_Id='$Voter_Id',Pan_Id='$Pan_Id',Aadhar_Id='$Aadhar_Id',Gender='$Gender',Email_iId='$Email_iId',Father_Name='$Father_Name', Mother_Name='$Mother_Name'");
																																																																																																																											
								if($update)
								{
									echo "Registered successfully";
							$move=move_uploaded_file($_FILES['Image']['tmp_name'],"user/".$Image);
							$move=move_uploaded_file($_FILES['Voter_Id']['tmp_name'],"user/".$voter);
							$move=move_uploaded_file($_FILES['Pan_Id']['tmp_name'],"user/".$pan);
							$move=move_uploaded_file($_FILES['Aadhar_Id']['tmp_name'],"user/".$aadhar);
							
								}
								else
								{
									echo "Failure";
								}
							}
?>
		</div>
		
		</form>
</div>
						<?php } ?>

 <?php include "layouts/footer.php"; ?>

 