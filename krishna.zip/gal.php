  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
  <script> 
function sum() 
{ 
var z = document.getElementById("fee").value; 
var q = document.getElementById("adv").value; 
document.getElementById("balance").value =((z*1)-(q*1));  
} 
</script>
     


            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
               
<?php
$qry=mysql_query("select * from soft");
$n=mysql_num_rows($qry);
?>
			       <div class="page-title">
              <div class="title_left">
                <h3>Mission task</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                  
                    <span class="input-group-btn">
                      <button class="btn btn-primary" type="button"><a href="vgal.php"><font color="white">VIEW!</font></a></button>
                
                      <button class="btn btn-info" type="button"><a href="gal.php"><font color="white">CREATE!</font></a></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
               <div class="col-md-6 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Mission  <small>Task</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
<form name="form8" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
 <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Image</label>
      <input cols="6" rows="5" type="file"  class="form-control" id="inputPassword3" name="image" value="" placeholder=""/>
  </div>
  
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Name</label>
      <input type="text" class="form-control" id="inputPassword3" name="name" value="" placeholder="Name">

  </div>
  
   <div class="form-group">
    <div class="col-sm-offset-2 col-sm-3">
      <button type="submit"  name="s17" class="btn btn-success btn-lg btn-block">Save</button>
	  
    </div>
  </div>

    </div>
                </div>
              </div>
      
	 <div class="col-md-6 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                         <h2>Mission <small>Entry</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br /> 
					 
   
  
      </div>
						</div>
					
                        </section><!-- right col -->				
						
                    </div><!-- /.row (main row) -->
    
		<div>  
<?php
							if(isset($_POST['s17']))
							{
							$gg = 0;
								extract($_POST);
								
								$image=$_FILES['image']['name'];
								$new = 0;
								$insert=mysql_query("INSERT INTO `galary`(`image`, `name`) 
								VALUES('$image','$name')");
								
								if($insert)
								{
								$move=move_uploaded_file($_FILES['image']['tmp_name'],"user/".$image);	
 
   	echo "Registered Successfully";
								
								}
								else
								{
									echo "Failure";
								}
							}
?>

		</div>
		
		
		</form></div>
</div>
</div></div>
</section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
 <?php include "layouts/footer.php"; ?>

    </body>
</html>
</html>