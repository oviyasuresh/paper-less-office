  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
  <script> 
function sum() 
{ 
var z = document.getElementById("fee").value; 
var q = document.getElementById("adv").value; 
document.getElementById("balance").value =((z*1)-(q*1));  
} 
</script>
     


            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
               
<?php
$qry=mysql_query("select * from soft");
$n=mysql_num_rows($qry);
?>
			       <div class="page-title">
              <div class="title_left">
                <h3>EVENT NEW ENTRY</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                  
                    <span class="input-group-btn">
                      <button class="btn btn-primary" type="button"><a href="app5.php"><font color="white">VIEW!</font></a></button>
                
                      <button class="btn btn-info" type="button"><a href="newevent.php"><font color="white">CREATE!</font></a></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
               <div class="col-md-6 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>TASK  <small>Entry</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
<form name="form8" class="form-horizontal" method="post" action="" enctype="multipart/form-data">

  
 
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3">EVENT TITLE</label>
        <input type="text" class="form-control" id="inputPassword3" name="name" value="">
  </div>
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Event From Date</label>
        <input type="text" class="form-control" id="inputPassword3" name="fdate" value="" onfocus="insertDate(this,'DD-MM-YYYY')">
  </div>
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Event To Date</label>
        <input type="text" class="form-control" id="inputPassword3" name="tdate" value="" onfocus="insertDate(this,'DD-MM-YYYY')">
  </div>

    </div>
                </div>
              </div>
      
	 <div class="col-md-6 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                         <h2> <small>Entry</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br /> 
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Description</label>
      <textarea cols="6" rows="5" type="text"  class="form-control" id="inputPassword3" name="desc" value="" placeholder=""></textarea>
  </div>
 
       <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Ref Link</label>
        <input type="text" class="form-control" id="inputPassword3" name="ref" value="">
  </div>
   
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-3">
      <button type="submit"  name="s17" class="btn btn-success btn-lg btn-block">Save</button>
	  
    </div>
  </div> 
      </div>
						</div>
														
		 
							
                            <!-- /.box -->
		
                        	

                        </section><!-- right col -->				
						
                    </div><!-- /.row (main row) -->
          
       		  

		<div>  
<?php
							if(isset($_POST['s17']))
							{
							$gg = 0;
								extract($_POST);
								$new = 0;
								$insert=mysql_query("INSERT INTO `event`(`Start_Date`, `End_Date`, `Event Name`,`Description`, `RefLink`) 
								VALUES('$name','$fdate','$tdate','$desc','$ref')");
								
								if($insert)
								{
								 
 
    $email_subject = "INFOSSEL:You Have New Received A New Task".$type;
 
   if($staff=='Selvaprabu') { $eemail = "md@infossel.in"; }
    if($staff=='Gowri') { $eemail = "gowri@infossel.in"; }
	 if($staff=='Prasanth') { $eemail = "prasanth@infossel.com"; }
	  if($staff=='SAdmin') { $eemail = "SAdmin@infossel.com"; }
	   if($staff=='Gowtham') { $eemail = "gowtham@infossel.in"; }
 
    $first_name = $type; // required
 
    $last_name = $desc; // required
 
    $email_from = "support@infossel.in";  // required
 $email_to = $eemail;
    $telephone = $edate; // not required
	 $telephone2 = $staff; // not required
 
    $comments = $cname; // required
 
     
 
    $error_message = "";
 
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
 
  if(!preg_match($email_exp,$email_from)) {
 
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
 
  }
 
    $string_exp = "/^[A-Za-z .'-]+$/";
 
    $email_message = "INFOSSEL SOFT SOLUTIONS MEMO MANAGEMENT.\n\n";
 
     
 
    function clean_string($string) {
 
      $bad = array("content-type","bcc:","to:","cc:","href");
 
      return str_replace($bad,"",$string);
 
    }
 
     $email_message .= "Task For : ".clean_string($comments)."\n";
 
    $email_message .= "Issue Type: ".clean_string($first_name)."\n";
 
    $email_message .= "About Issue : ".clean_string($last_name)."\n";
 
 
 
     
 
     
 
// create email headers
 
$headers = 'From: '.$email_from."\r\n".
 
'Reply-To: '.$email_from."\r\n" .
 
'X-Mailer: PHP/' . phpversion();
 
@mail($email_to, $email_subject, $email_message, $headers);  
 

						echo "Registered Successfully";
								
								}
								else
								{
									echo "Failure";
								}
							}
?>
		</div>
		
		
		</form></div>
</div>
</div></div>
</section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
 <?php include "layouts/footer.php"; ?>

    </body>
</html>
</html>