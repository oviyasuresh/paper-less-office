  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">

    function PrintElem(elem)
    {
        Popup($(elem).html());
    }

    function Popup(data) 
    {
        var mywindow = window.open('', 'my div', 'height=400,width=600');
        mywindow.document.write('<html><head><title>INFOSSEL SOFT SOLUTIONS</title>');
        /*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
        mywindow.document.write(' <h1 style="color:green;text-align:center;" >INFOSSEL SOFT SOLUTIONS</h1><body >');
        mywindow.document.write(data);
        mywindow.document.write('<h3 style="text-align:right;">Signed by</h3><h3 style="color:blue;text-align:right;">For INFOSSEL SOFT SOLUTIONS</h3></body></html>');

        mywindow.print();
        mywindow.close();

        return true;
    }

</script>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
  
        <?php include "layouts/menu1.php"; ?>
	<?php $vno=$_REQUEST['vno'];?>
    
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h4>
                       Vehicle Details Deletion &nbsp;&nbsp;
                        <button type="submit"><a href="vtrans.php">View</a></button>&nbsp;&nbsp;&nbsp;&nbsp;
	    <button type="submit"><a href="transveh.php">Add</a></button>&nbsp;&nbsp;&nbsp;&nbsp;
  <button type="submit"><a href="update.php">Update</a></button>
 
  </br></br>
                       
                    </h4>
                 
                </section>

                <!-- Main content -->
                <section class="content">


                    <!-- top row -->
                    <div class="row">
                        <div class="col-xs-12 connectedSortable">
                            
                        </div><!-- /.col -->
                    </div>
                    <!-- /.row -->
	
                    <!-- Main row -->
                             <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                            
        <div id="mydiv">
  <input type="button" value="Print" onclick="PrintElem('#mydiv')"  style="margin:20px;">
  
                    <form name="form1" method="post" action="" enctype="multipart/form-data">
						<?php
						$qry=mysql_query("select * from customer where vno='$vno'");
						?>
					<?php 
					$row=mysql_fetch_array($qry)
					?>
					<table class="table table-striped" >
					<col width="150px">
					<tbody style="color:#FF0080;background:white;">
      					
							
						<tr>
						<td style="background-color:#FFAAAA;">Vehicle No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['vno'];?></td>
						</tr>
					
						<tr>
						<td style="background-color:#FFAAAA;">Reg Date</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['rdate'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Model</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['model'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Engine No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['enum'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Chasis No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['cnum'];?></td>
						</tr>
						
						<tr>
						<td style="background-color:#FFAAAA;">Party Name</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['name'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Address</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['add'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Ph.No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['pno'];?></td>
						</tr>
				
						<tr>
						<td style="background-color:#FFAAAA;">Remark</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['rmak'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Tax </td>
						<td style="background-color:#FFD4FF;"><?php echo $row['tax'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Tax Paid At</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['taxat'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Tax Amount</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['tamt'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Tax From Date</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['texp'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Tax To Date</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['texp2'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Financier Name</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['ffname'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Financier Phone No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['ffpno'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Green Tax From</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['gtax'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Green Tax To</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['gtax2'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Gtax Paid At</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['gtaxat'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Gtax Amount</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['gamt'];?></td>
						</tr>
												
						<tr>
						<td style="background-color:#FFAAAA;">Permit No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['per'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">Permit Exp Date</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['perexp'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">I.C Name</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['icname'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">I.C Amount</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['icamt'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">I.C Date From</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['icdate'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">I.C Date To</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['icdate2'];?></td>
						</tr>
						<tr>
						<td style="background-color:#FFAAAA;">I.C Policy No</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['fc'];?></td>
						</tr>
						
						<tr>
						<td style="background-color:#FFAAAA;">FC Exp Date</td>
						<td style="background-color:#FFD4FF;"><?php echo $row['fcexp'];?></td>
						</tr>
						
						
						<tr>
						<td style="background-color:#FFAAAA;">Delete</td>						
						<td style="background-color:#FFD4FF;"><button type="submit" class="btn btn-default" name="s1">Delete</button></td>
						</tr>
						
							<div class="alert alert-warning">
							<?php
							if(isset($_POST['s1']))
							{
								extract($_POST);
								$qry=mysql_query("select * from customer where vno='$vno'");
								$n=mysql_num_rows($qry);
								if($n==0)
									{
										echo"Already Deleted";
									}
								else		
									{
										$delete=mysql_query("delete from customer where vno='$vno'");
										if($delete)
										{
										echo"Deleted";
										}
										else
										{
										echo "Try Again";
										}
									}
							}			
							
						   
								
?>							</div>										
					</tbody>		
					</table>
					</form>
</div>
</div></div>
</div></div></div></div></section>
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>