  <?php include "layouts/menu.php"; ?>
		
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
   
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>

		   <script>
	function autocomplet() {
	var min_length = 0; // min caracters to display the autocomplete
	var keyword = $('#did').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'ajax_refreshentry.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#country_list_id').show();
				$('#country_list_id').html(data);
			}
		});
	} else {
		$('#country_list_id').hide();
	}
}

// set_item : this function will be executed when we select an item
function set_item(item) {
	// change input value
	$('#did').val(item);
	// hide proposition list
	$('#country_list_id').hide();
}
	</script>

    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script type="text/javascript">
function CollapseForm()
{
// Two places to customize:

// Specify the id of the form.
var IDofForm = "form1";

// Specify the id of the div containing the form.
var IDofDivWithForm = "demo";

// This line submits the form. (If Ajax processed, call Ajax function, instead.)
document.getElementById(IDofForm).submit();

// This line collapses the form.
document.getElementById(IDofDivWithForm).style.display = "none";
}
</script>
     
    <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
              <section class="content-header">
                    <div class="col-lg-6">  	
   
   <button class="btn btn-success btn-lg" type="submit"><a href="yentry.php">&nbsp;<font color="white">View&nbsp;&nbsp;&nbsp;</font></a></button>&nbsp;&nbsp;&nbsp;&nbsp;
  <button class="btn btn-danger  btn-lg" type="submit"><a href="entry.php"><font color="white">&nbsp;Add&nbsp;&nbsp;&nbsp;</font></a></button>
  
  </br></br>
</div>

  <div class="pull-right box-tools">


    


  
  

  
  
  
                                        <button class="btn btn-danger btn-sm refresh-btn" data-toggle="tooltip" title="Reload"  ><i class="fa fa-refresh"></i></button>
                                        <button class="btn btn-danger btn-sm" data-widget='collapse' data-toggle="tooltip" title="Collapse" ><i class="fa fa-minus"></i></button>
                                        <button class="btn btn-danger btn-sm" data-widget='remove' data-toggle="tooltip" title="Remove" ><i class="fa fa-times"></i></button>
                                    </div>

                </section>  <a href="add_sales_print.php">Printview</a>
		<div id="col-lg-12">		
 <div class="col-lg-3">  
								 		
					   <form  id="form1" name="form3" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
 <?php $qry=mysql_query("select * from master"); ?>

	 <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Version</label>
     <div class="col-sm-4">
      <select type="submit"    class="form-control" id="inputPassword3" name="ver" value=""><option>Select</option>
	  <?php
	  while($row1=mysql_fetch_array($qry))
{
 	?>
	  <option><?php echo $row1['name'];?></option>
	  <?php
	  }
	  
	  ?>
	  </select>
   </div>    </div>
	<div class="col-sm-offset-2">
      <button type="submit" class="btn btn-warning" name="s55">Search</button>
    </div>
 	
 
    
      <div>
	  <?php
								if(isset($_POST['s55']))
								{
									extract($_POST);
									
										header("location:yentry3.php?ver=$ver");
									
								}
							?>
	  </div>
</form>
		</div>
		<div class="col-lg-3">  
								 </br>			
					   <form  id="form1" name="form3" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
 <?php $qry=mysql_query("select * from master"); ?>

	 <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">OK List</label>
     <div class="col-sm-4">
      <select type="submit"    class="form-control" id="inputPassword3" name="ver" value=""><option>Select</option>
<option>Ok</option>	 
	 <option>Medium</option>
	 <option>Confirm</option>
	  <option>Not Now</option>  
	  <option>No Idea</option>  
	  <option>Other</option>  
	
	  </select>
   </div>    
	<div class="col-sm-offset-2">
      <button type="submit" class="btn btn-warning" name="s5">Search</button>
    </div></div>
 	
 
    
      <div>
	  <?php
								if(isset($_POST['s5']))
								{
									extract($_POST);
									
										header("location:yentry4.php?ver=$ver");
									
								}
							?>
	  </div>
</form>
		 </div>
 <div class="col-lg-3">  
 <form  id="form13" name="form33" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Update Sms</label>
    <div class="col-sm-8">
      <textarea type="text" class="form-control" name="sms" value="" placeholder="Name" ></textarea>
     
    </div>
	<div class="col-sm-offset-2">
      <button type="submit" class="btn btn-warning" name="s54">Update</button>
    </div>
  </div>	
 
    
      <div>
	  <?php
								if(isset($_POST['s54']))
								{
									extract($_POST);
									$insert=mysql_query("insert into sentry(sms)
											 values('$sms')");
								
								if($insert)
								{
									
									echo "Registered Successfully";
									header("location:yentry.php");
								}
								else
								{
									echo "Failure";
									}
								}
							?>
	  </div>
</form>
   
  </div>
 
 
  </div>	
  			
                    <?php
					
						$qry=mysql_query("select * from entry ORDER BY id DESC");
						$n=mysql_num_rows($qry);
						if($n==0)
						{
							echo "Nothing To Display";
						}
						else
						
					{ 
						?>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                  
                        <div class="col-xs-12"> 
                          <?php $qry22=mysql_query("select * from sentry"); 
 while($row22 = mysql_fetch_array($qry22))
 {
	 $cont = $row22['sms'];
 } ?>	
<h5>SMS Content : <?php echo $cont; ?></h5>	
                            <div class="box">
                               <!-- /.box-header -->
                                <div class="box-body table-responsive">
                                <div id="mydiv">
<input type="button" value="Print" onclick="PrintElem('#mydiv')"  style="margin:20px;"> <div  style="overflow: scroll">
                                    <table id="table2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr class="danger">
                                                <th>S.no</th>
                                                <th>Name</th>
                                                <th colspan="2">EDate</th>
												<th>M.no</th>
												<th>Ph.no</th>
												<th>Email Id</th>
												<th>Version</th>

												<th>R.Cat</th>
												
												<th>Response</th>
												<th>R.date</th>
                                                <th>Edit</th>	
                                                <th>DELETE</th>	
                                                <th>SMS</th>
                                                <th>Demo SMS</th>		
                       <!-- <th>App SMS</th>		
						<th>App.date</th>
						<th>App.Det</th>-->
						<th>Mar Via</th>
						<th>Maintainer</th>
																	
                                            </tr>
                                        </thead>
										<?php $tg = 0;
					while($row2=mysql_fetch_array($qry))
						{ $tg++;
					?>
                                        <tbody>
                                           <tr>
                                           <td><?php echo $tg;?></td>
                                               <td><?php echo $row2['cname'];?></td>
						<td colspan="2"><?php echo $row2['hpdate']; ?></td>
						<td><?php echo $row2['pno']; ?></td>
						<td><?php echo $row2['pno2']; ?></td>
						<td><?php echo $row2['email']; ?></td>
                 		<td><?php echo $row2['ver'];?></td>

						<td><?php echo $row2['rcat'];?></td>
						
						<td><?php echo $row2['cno'];?></td>
						<td><?php echo $row2['rdate'];?></td>

						<td><a href="uentry.php?id=<?php echo $row2['id'];?>">Edit</a></td>
						<td><a href="dentry.php?id=<?php echo $row2['id'];?>">Delete</a></td><?php $tr = $row2['pno']; ?>
						<td><a href="http://login.bulksmsgateway.in/sendmessage.php?user=kongudevaraj&password=9965577155&mobile=<?php echo $tr ?>&message=Hello <?php echo $row2['name'] ?> <?php echo $cont ?>&sender=INFOSL&type=3">Send SMS</a></td>
						<td><a href="http://login.bulksmsgateway.in/sendmessage.php?user=kongudevaraj&password=9965577155&mobile=<?php echo $tr ?>&message=Hello <?php echo $row2['name'] ?> Thank you for interesting with INFOSSEL SOFTWARES .Your Software demo link <?php echo $row2['ver'] ?>.infossel.com username admin password password123 . Ph 0422 4373220 Mb 9952292120.&sender=INFOSL&type=3">Send SMS</a></td>
                        <!--<td><a href="http://login.bulksmsgateway.in/sendmessage.php?user=kongudevaraj&password=9965577155&mobile=9952292120,9003612442&message=Hello Today Appointment <?php echo $row2['cname'];?> <?php echo $row2['pno']; ?> <?php echo $row2['pno2']; ?> <?php  echo $row2['address']; ?>&sender=INFOSL&type=3">Send SMS</a></td>                    
						<td><?php //echo $row2['adate'];?></td>
						<td><?php //echo $row2['aremark'];?></td>-->
						<td><?php echo $row2['class'];?></td>
						<td><?php echo $row2['fee'];?></td>
						</tr>
                                          
										  </tbody>
                                        <?php
						}
					}
				
					?>
					                    
                                    </table>		
                                </div>  </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div></div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>