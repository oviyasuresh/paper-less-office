<?php ob_start(); ?>
<!DOCTYPE html>
<html>
<?php include "layouts/db_connect.php"; ?>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Ministry of Defence</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">
   <link rel="stylesheet" href="font.css">     <style type="text/css">
		/* when @font-face is defined(it is in font.css) you can add the font to any rule by using font-family */
		h1 {
			font-family: 'BAUHS93';
		}
		body{
			img src="user/12.jpg" width="100%" height="100%"
			
		}
		
		</style>
    <!-- Custom Theme Style -->
     <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body  style="background-image:url(user/12.jpg); 
    background-repeat: no-repeat;
    background-size: cover;"  width="100%" height="100%">
    <div >

      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
       <form class="form-horizontal" method="post" action="" enctype="multipart/form-data" role="form">
          <img src="user/11.png" width="150px" height="150px">
              <div>
                <input type="text" name="uname" class="form-control" placeholder="Soldier_Id" required="" />
              </div>
              <div>
                <input type="password" name="pwd" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
             
				<button type="submit" class="btn btn-default submit" name="s2" href="#">Log in</button>
               <!-- <a class="reset_pass" href="#">Lost your password?</a>-->
              </div>

              <div class="clearfix"></div>

              <div class="separator">
              <!--  <p class="change_link">New to site?
                  <a href="#signup" class="to_register"> Create Account </a>
                </p>-->

                <div class="clearfix"></div>
                <br />

                <div>
                  <!--<h1><i class="fa fa-paw"></i> Ministry of Defence</h1>-->
                  <p>©2018 All Rights Reserved. </p>
                </div>
              </div>
            <div>
	  <?php
								if(isset($_POST['s2']))
								{
									extract($_POST);
									session_start('ERP');	
							 $uname = str_replace(' ', '-', $uname); 

  $uname = preg_replace('/@![^A-Za-z0-9\-]/', '', $uname);
     $pwd = str_replace(' ', '-', $pwd); 

  $pwd = preg_replace('/@![^A-Za-z0-9\-]/', '', $pwd);
									$qry=mysql_query("select * from soldier where Soldier_Id='$uname' && Password='$pwd'");
																
                						
									$n=mysql_num_rows($qry);
									
									if($n==0)
									{
										echo "Invalid username or password";
									}
									else
									{
										$_SESSION['uname']=$uname;
					                                        $_SESSION['pwd']=$pwd;						
										$row=mysql_fetch_array($qry);
										$_SESSION['code']=$row['Soldier_Id'];
										$_SESSION['name']=$row['Name'];
										$_SESSION['postt']=$row['Designation'];
										header("location:index2.php");
									}
								}
							?>
	 </div> </form>
          </section>
        </div>

        <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form>
              <h1>Create Account</h1>
              <div>
                <input type="text" class="form-control" placeholder="Username" required="" />
              </div>
              <div>
                <input type="email" class="form-control" placeholder="Email" required="" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <a class="btn btn-default submit" href="index.html">Submit</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="#signin" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                <!--  <h1><i class="fa fa-paw"></i> Ministry of Defence</h1>-->
                  <p>©2018 All Rights Reserved. Ministry of Defence</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>

    </div>
  </body>
</html>
