  <?php include "layouts/menu.php"; ?>
        <div class="right_col" role="main">
         <div class="x_content">
                    <p><code>FILTERS</code> </p>
              <?php     $qry09=mysql_query("select * from entry where rcat='ok'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry4.php?ver=ok" class="btn btn-app  bg-blue">
                     <span class="badge bg-blue"><?php echo $nok; ?></span>
                      <i class="fa fa-thumbs-o-up"></i> OK LIST
                    </a>
                          <?php     $qry09=mysql_query("select * from entry where rcat='confirm'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry4.php?ver=Confirm" class="btn btn-app bg-green">
                     <span class="badge bg-blue"><?php echo $nok; ?></span>
                      <i class="fa fa-thumbs-o-up"></i> CONFIRM LIST
                    </a>
                          <?php     $qry09=mysql_query("select * from entry where rcat='medium'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry4.php?ver=medium" class="btn btn-app bg-orange">
                     <span class="badge bg-red"><?php echo $nok; ?></span>
                      <i class="fa fa-shield"></i> MEDIUM LIST
                    </a>
                          <?php     $qry09=mysql_query("select * from entry where rcat='no idea'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry4.php?ver=no idea" class="btn btn-app bg-brown">
                     <span class="badge bg-green"><?php echo $nok; ?></span>
                      <i class="fa fa-thumbs-o-down"></i> NO IDEA
                    </a>
                          <?php     $qry09=mysql_query("select * from entry where rcat='not now'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry4.php?ver=not now" class="btn btn-app bg-red">
                    <span class="badge bg-green"><?php echo $nok; ?></span>
                      <i class="fa fa-thumbs-o-down"></i> NOT NOW
                    </a>
                          <?php     $qry09=mysql_query("select * from entry where ver='billing'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry3.php?ver=billing" class="btn btn-app">
                     <span class="badge bg-orange"><?php echo $nok; ?></span>
                      <i class="fa fa-bar-chart"></i> BILLING
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='finance'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry3.php?ver=finance" class="btn btn-app">
                    <span class="badge bg-orange"><?php echo $nok; ?></span>
                      <i class="fa fa-rupee"></i> AUTO FINANCE
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='matrimony'"); $nok = mysql_num_rows($qry09); ?>
                    <a  href="yentry3.php?ver=matrimony" class="btn btn-app">
                       <span class="badge bg-yellow"><?php echo $nok; ?></span>
                      <i class="fa fa-inbox"></i> MATRIMONIAL
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='medical'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry3.php?ver=medical" class="btn btn-app">
                    <span class="badge bg-pink"><?php echo $nok; ?></span>
                      <i class="fa fa-plus-square"></i> MEDICAL
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='hospital'"); $nok44 = mysql_num_rows($qry09); ?>
                    <a href="yentry3.php?ver=hospital" class="btn btn-app">
                     <span class="badge bg-green"><?php echo $nok44; ?></span>
                      <i class="fa fa-user-md"></i> HOSPITAL
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='driving'"); $nok = mysql_num_rows($qry09); ?>
                    <a href="yentry3.php?ver=driving" class="btn btn-app">
                      <span class="badge bg-blue"><?php echo $nok; ?></span>
                      <i class="fa fa-cab"></i> DRIVING SCHOOL
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='goldfinance'"); $nok = mysql_num_rows($qry09); ?>
					 <a href="yentry3.php?ver=goldfinance" class="btn btn-app">
                       <span class="badge bg-red"><?php echo $nok; ?></span>
                      <i class="fa fa-rupee"></i> GOLD FINANCE
                    </a>
                    <?php     $qry09=mysql_query("select * from entry where ver='school'"); $nok = mysql_num_rows($qry09); ?>
					 <a href="yentry3.php?ver=school" class="btn btn-app">
                  <span class="badge bg-green"><?php echo $nok; ?></span>
                      <i class="fa fa-university"></i> SCHOOL
                    </a>
                 </br>
        
           </DIV> <?php  $qry11=mysql_query("select * from customer"); while($row11 = mysql_fetch_array($qry11)){ 
           $nname = $row11['name'];
                $qry09=mysql_query("select * from entry where fee='$nname'"); $nok = mysql_num_rows($qry09); ?>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <a href="yentry5.php?ver=<?php echo $row11['name']; ?>"><img src="user/<?php echo $row11['uimg']; ?>" width="70px" height="70px"></a>  <span class="badge bg-green"><?php echo $nok; ?></span> <?php } ?>
            <div class="clearfix"></div>

           <?php
					
						$qry=mysql_query("select * from entry ORDER BY id DESC"); ?>
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Enquiry <small>Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">  <p class="text-muted font-13 m-b-30"> <a href="fullview.php">Full View</a>
                       </p>
                    <table  id="datatable-buttons" class="table table-striped table-bordered  dt-responsive nowrap">
                      <thead>
                        <tr>
                         <th style="width: 1%">S.no</th>
                                                <th style="width: 10%">Name</th>
                                                <th style="width: 10%">EDate</th>
												<th style="width: 10%">M.no</th>
												
											
												<th>Version</th>

												<th>R.Cat</th>
												
												<th>Response</th>
												<th>R.date</th><th>Address</th>
                                                <th></th>	
                                               	
						<th>Mar Via</th>
						<th>Maintainer</th>

                        </tr>
                      </thead>


                      <tbody>
										<?php  $tg = 0;
					while($row2=mysql_fetch_array($qry))
						{ $tg++;
				
					?>
                                       
                                           <tr>
                                            <td><small><?php echo $tg;?></small></td>
                                               <td><small><?php echo $row2['cname'];?></small></td>
						<td><small><?php echo $row2['hpdate']; ?></small></td>
						<td style="width: 10%"><small><?php echo $row2['pno']; ?></small></td>
						<td><small><?php echo $row2['ver'];?></small></td>

						<td><small><?php echo $row2['rcat'];?></small></td>
						
						<td><small><?php echo $row2['cno'];?></small></td>
						<td><small><?php echo $row2['rdate'];?></small></td>
					<td><small><?php echo $row2['address']; ?><?php echo $row2['pno2']; ?><?php echo $row2['email']; ?></small></td>
                 		
<td><a href="uentry.php?id=<?php echo $row2['id'];?>"><i class="fa fa-edit"></i></a>
<a href="dentry.php?id=<?php echo $row2['id'];?>"><i class="fa fa-eraser"></i></a>
<?php $tr = $row2['pno']; ?>
<a href="http://login.bulksmsgateway.in/sendmessage.php?user=kongudevaraj&password=9965577155&mobile=<?php echo $tr ?>&message=Hello <?php echo $row2['name'] ?> <?php echo $cont ?>&sender=INFOSL&type=3"><i class="fa fa-mail-forward"></i></a>
<a href="http://login.bulksmsgateway.in/sendmessage.php?user=kongudevaraj&password=9965577155&mobile=<?php echo $tr ?>&message=Hello <?php echo $row2['name'] ?> Thank you for interesting with INFOSSEL SOFTWARES .Your Software demo link <?php echo $row2['ver'] ?>.infossel.com username admin password password123 . Ph 0422 4373220 Mb 9952292120.&sender=INFOSL&type=3"><i class="fa fa-mail-forward"></i></a></td>
                     
						<td><small><?php echo $row2['class'];?></small></td>
						<td><small><?php echo $row2['fee'];?></small></td>

						</tr>
                                          
										  
                                        <?php
						} 
				
				
					?></tbody>
                    </table>
                  </div>
                </div>
              </div>
  <div class="page-title">

                 <div class="col-md-4">  
								 		
					   <form  id="form1" name="form3" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
 <?php $qry=mysql_query("select * from master"); ?>

	 <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Version</label>
     <div class="col-sm-4">
      <select type="submit"    class="form-control" id="inputPassword3" name="ver" value=""><option>Select</option>
	  <?php
	  while($row1=mysql_fetch_array($qry))
{
 	?>
	  <option><?php echo $row1['name'];?></option>
	  <?php
	  }
	  
	  ?>
	  </select>
   </div>    </div>
	<div class="col-sm-offset-2">
      <button type="submit" class="btn btn-warning" name="s55">Search</button>
    </div>
 	
 
    
      <div>
	  <?php
								if(isset($_POST['s55']))
								{
									extract($_POST); 
									header("location:yentry3.php?ver='$ver'");
									
								}
							?>
	  </div>
</form>
		</div>
       <div class="col-md-4">  
								 </br>			
					   <form  id="form1" name="form3" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
 <?php $qry=mysql_query("select * from master"); ?>

	 <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">OK List</label>
     <div class="col-sm-4">
      <select type="submit"    class="form-control" id="inputPassword3" name="ver" value=""><option>Select</option>
<option>Ok</option>	 
	 <option>Medium</option>
	 <option>Confirm</option>
	  <option>Not Now</option>  
	  <option>No Idea</option>  
	  <option>Other</option>  
	
	  </select>
   </div>    
	<div class="col-sm-offset-2">
      <button type="submit" class="btn btn-warning" name="s5">Search</button>
    </div></div>
 	
 
    
      <div>
	  <?php
								if(isset($_POST['s5']))
								{
									extract($_POST);
								echo '<meta http-equiv="refresh" content="1;yentry4.php?ver='.$ver.'" />';
										// header("location:yentry4.php?ver=$ver");
									
								}
							?>
	  </div>
</form>
		 </div>
 <div class="col-md-4">  
 <form  id="form13" name="form33" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Update Sms</label>
    <div class="col-sm-8">
      <textarea type="text" class="form-control" name="sms" value="" placeholder="Name" ></textarea>
     
    </div>
	<div class="col-sm-offset-2">
      <button type="submit" class="btn btn-warning" name="s54">Update</button>
    </div>
  </div>	
 
    
      <div>
	  <?php
								if(isset($_POST['s54']))
								{
									extract($_POST);
									$insert=mysql_query("insert into sentry(sms)
											 values('$sms')");
								
								if($insert)
								{
									
									echo "Registered Successfully";
									header("location:yentry.php");
								}
								else
								{
									echo "Failure";
									}
								}
							?>
	  </div>
</form>
   
  </div>
            </div>

             

            </div>
          </div>
        </div>
        <!-- /page content -->



  <?php include "layouts/footer.php"; ?>

  </body>
</html>