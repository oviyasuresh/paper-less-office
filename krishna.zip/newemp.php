  <?php include "layouts/menu.php"; ?>
		
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
     
   <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        NEW EMPLOYEE
                       
                    </h1>
                 
                </section>
				 <div class="panel-body">
                            <div class="row">
 <div class="col-lg-12">  
								 </br>
				
									  <div class="alert alert-info">New Registration For Staff</div>
                           <div class="col-lg-6">
   <form role="form" name="form1" method="post" action="newemp.php" enctype="multipart/form-data">
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Name of the Staff</label>
      <input type="text" class="form-control" id="inputPassword3" name="name" required>
 </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Staff code</label>
      <input type="text" class="form-control" id="inputPassword3" name="code" required>
 </div>
  <div class="form-group has-success has-feedback">
    <label for="inputEmail3" >Father/Spouse Name</label>
      <input type="text" class="form-control" id="inputEmail3" name="fname" value="">
  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputEmail3" >Upload Image</label>
    <input type="file" id="exampleInputFile" name="uimg" >
    <p class="help-block">Upload Passport size Photo here.</p>
  </div>  
  
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Previous year of Experience</label>
      <input type="text" class="form-control" id="inputPassword3" name="exp" value="1">
	 <input type="text" class="form-control" id="inputPassword3" name="expr" value="2">
 
  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Education Qualification</label>
      <input type="text" class="form-control" id="inputPassword3" name="edu" value="">
  </div>
   </div> <div class="col-lg-6">
  
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Total year/month of Experience</label>
      <input type="text" class="form-control" id="inputPassword3" name="year" value="">
    <span class="glyphicon glyphicon-tint form-control-feedback"></span>
  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Co-curricular Activities</label>
      <input type="text" class="form-control" id="1" name="act"  value="">
  </div>
 <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Interested area</label>
      <input type="text" class="form-control" id="2" name="inter"  value="">
     <span class="glyphicon glyphicon-info-sign form-control-feedback"></span>
  </div>
 <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Address</label>
      <input type="text" class="form-control" id="datepicker" name="id" value="">
    </div> 
     <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Mobile No</label>
      <input type="text" class="form-control" id="datepicker" name="mno" value="">
    </div>
     <div class="form-group has-success has-feedback">
    <label for="inputPassword3">E-Mail</label>
      <input type="text" class="form-control" id="datepicker" name="mail" value="">
    </div>
	 <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Joining Date</label>
      <input type="date" class="form-control" id="datepicker" name="yearr" value="">
    </div> 
     <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Designation</label>
      <select type="text" class="form-control" id="datepicker" name="desig" value="">
      <option>MD</option>
      <option>AO</option>
      <option>Marketting</option>
      <option>Developer</option>
      <option>Other</option></select>
    </div> 
	</div>
   
 <div class="form-group">
  
      <button type="submit" class="btn btn-primary btn-lg btn-block" name="s5">Register</button>

  </div>   <div>
	 
<?php
							if(isset($_POST['s5']))
							{
								extract($_POST);
								$uimg=$_FILES['uimg']['name'];
								
								$insert=mysql_query("INSERT INTO `customer`(`name`, `code`, `fname`, `uimg`, `edu`, `exp`, 
								`expr`, `year`, `act`, `inter`, `id`, `desig`,`mail`,`mno`,`pwd`) VALUES ('$name', '$code','$fname', '$uimg', '$edu', '$exp','$expr', '$year','$act','$inter','$id','$desig','$mail','$mno','$mno')");
								if($insert)
								{
								$move=move_uploaded_file($_FILES['uimg']['tmp_name'],"user/".$uimg);	
								echo "Sucessful";	
								}
								else
								{
									echo "Failure";
								}
							}
?>	 
	  </div>
</form>
</div></div></div>
  
  		<div class="alert alert-info">Staff Details</div>
  
                    <?php
					
						$qry=mysql_query("select * from customer");
						$n=mysql_num_rows($qry);
						if($n==0)
						{
							echo "Nothing To Display";
						}
						else
					{ 
						?></p>
						<div class="table-responsive">
					<table class="table table-bordered table-hover"><thead>
  <tr class="info">
						<th>Staff Code</th>
						<th>Name</th>
						<th>User Image</th>
						<th>Educational Qualification</th>
						<th>Experience</th>
						<th>More Details</th>
					</tr></thead>
					<?php 
					while($row=mysql_fetch_array($qry))
						{
					?>
					<tr class="warning"><tbody>
					<col width="100px">
						<td><?php echo $row['code'];?></td>
						<td><?php echo $row['name'];?></td>
						<td><img src="user/<?php echo $row['uimg'];?>" width="120" height="120"/></td>
						<td><?php echo $row['edu'];?></td>
						<td><?php echo $row['year'];?></td>
						<td><a href="m.udelete.php?hpl=<?php echo $row['name'];?>&name=<?php echo $row['name'];?>">More Info</a></td>
					</tr></tbody>
					<?php
						}
					}
				
					?>
					</table>                        </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>