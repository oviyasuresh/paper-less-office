   <?php include "layouts/menu.php"; ?>
        <!-- page content -->
        <div class="right_col" role="main">
<?php
$qry=mysql_query("select * from master");
$n=mysql_num_rows($qry);
?>
			 <div class="page-title">
              <div class="title_left">
                <h3>ENQUIRY ENTRY</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                  
                    <span class="input-group-btn">
                      <button class="btn btn-primary" type="button"><a href="ventry.php"><font color="white">VIEW!</font></a></button>
                
                      <button class="btn btn-info" type="button"><a href="entry.php"><font color="white">CREATE!</font></a></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
               <div class="col-md-4 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Marketting Enquiries <small>Fill the Details</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
<form name="form8" class="form-horizontal" method="post" action="" enctype="multipart/form-data">

  <div class="form-group has-success has-feedback">
    <label for="inputPassword3">Registration Date</label>
        <input type="text" class="form-control" id="inputPassword3" name="hpdate" value="" onfocus="insertDate(this,'DD-MM-YYYY')">
  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Company Name</label>
      <input type="text"    class="form-control" id="inputPassword3" name="cname" value="" placeholder="Name">

  </div>
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Name</label>
      <input type="text"    class="form-control" id="inputPassword3" name="name" value="" placeholder="Name">

  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Email ID</label>
      <input type="text"    class="form-control" id="inputPassword3" name="email" value="" placeholder="Name">

  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Address</label>
      <textarea  rows="4"  class="form-control" name="address" value="" placeholder="Address"></textarea>

  </div>
    
    </div>
                </div>
              </div>
        
	 <div class="col-md-4 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Form Design <small>different form elements</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Mobile Number</label>
      <input type="text"  class="form-control" id="inputPassword3" name="pno" value="" placeholder="Mb.no">
  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Phone Number</label>
      <input type="text"  class="form-control" id="inputPassword3" name="pno2" value="" placeholder="Ph.no">
  </div>
     <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Version</label>
     <select type="text"  name="ver"  class="form-control" id="inputPassword3"  value="" placeholder="">
<option>Select</option>
	  <?php $qry=mysql_query("select * from master");
	  while($row1=mysql_fetch_array($qry))
{
 	?>
	  <option><?php echo $row1['name'];?></option>
	  <?php
	  } ?>
	  </select>

  </div>
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Marketing Via</label>
      <select type="text" class="form-control" id="inputPassword3" name="class" value="" placeholder="">
         <option>Justdial</option>	 
	 <option>Phone</option>
	  <option>Direct Visit</option>
	  <option>BNI</option>
	   <option>Welfare Association</option>

	  
</select>   
  </div>
   
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-3">
      <button type="submit"  name="s1" class="btn btn-success btn-lg btn-block">Save</button>
	  
    </div>
  </div> 
  
    </div>
                </div>
              </div>
 <div class="col-md-4 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Form Design <small>different form elements</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

 <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Maintainer</label>
      <select type="text" class="form-control" id="inputPassword3" name="fee" value="" placeholder="">
<option>Selvaprabu</option>
 <option>SAdmin</option>	 
	 <option>Gowtham</option>
	  <option>Prasanth</option>
	  <option>Gowri</option>
	  <option>Pon Kowsick</option>
	 
	 
</select>   
  </div>
   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Response Cat</label>
      <select type="text" class="form-control" id="inputPassword3" name="rcat" value="" placeholder="">
<option>Ok</option>	 
	 <option>Medium</option>
	 <option>conform</option>
	  <option>Not Now</option>  
	  <option>No Idea</option>  
	  <option>Enquiry</option>  
	  <option>Other</option>  
</select>   
  </div>

   <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Response Details</label>
      <textarea  rows="3"  class="form-control" name="cno" value="" placeholder="Remark"></textarea>

  </div>
    <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Response Date</label>
      <input type="text"  class="form-control" id="inputPassword3" name="rdate" value="" placeholder="" onfocus="insertDate(this,'DD-MM-YYYY')">
  </div>
  <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Main Location</label>
      <input type="text"  class="form-control" id="inputPassword3" name="mlocation" value="" placeholder="mainlocation">
  </div>
     </div>
                </div>
              </div>
		  
<?php
							if(isset($_POST['s1']))
							{
								extract($_POST);
								$insert=mysql_query("INSERT INTO `entry`(`name`, `cname`, `pno`, `pno2`, `address`, `hpdate`, `ver`, `class`, `fee`, `cno`, `rcat`, `rdate`,`mainlocation`,`email`) 
								VALUES('$name','$cname','$pno','$pno2','$address','$hpdate','$ver','$class','$fee','$cno','$rcat','$rdate','$mlocation','$email')");

$username="infossel";

$password="infossel123.";

$message="HELLO use INFOSSEL SOFTWARE for your ".$cname." and get automate.Online Demo Link ".$ver.".infossel.in INFOSSEL SOFTWARE Ph 9952292120 MAIL md@infossel.in .";

$sender="INFOSL"; //ex:INVITE

$mobile_number=$pno;

$url="selvaprabhu.bulksms5.com/sendmessage.php?user=".urlencode($username)."&password=".urlencode($password)."&mobile=".urlencode($mobile_number)."&message=".urlencode($message)."&sender=".urlencode($sender)."&type=".urlencode('3');

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

echo $curl_scraped_page = curl_exec($ch);

curl_close($ch);

								
								if($insert)
								{
									
									echo "Registered Successfully";
								
								}
								else
								{
									echo "Failure";
								}
							}
?>
		</div>
		
		</form>
</div>
</div></div></div>

   <?php include "layouts/footer.php"; ?>

    </body>
</html>