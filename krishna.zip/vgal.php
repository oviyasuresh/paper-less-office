  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>
    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script>
function add()
{
var x = document.getElementById("txt1").value;
var y = document.getElementById("txt2").value;
document.getElementById("bal").value =(x*1)-(y*1);
}
</script>
     
  <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Galary Details
                      
                    </h1>
                   
                </section>
                   <div class="panel-body">
                            <div class="row">
   <div class="alert alert-info">Register Galary Details</div>
  
  		
				
                    <?php
					
						$qry=mysql_query("select * from galary");
						$n=mysql_num_rows($qry);
						if($n==0)
						{
							echo "Nothing To Display";
						}
						else
						
					{ 
						?>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12"> 
                            <div class="box">
                               <!-- /.box-header -->
                                <div class="box-body table-responsive">
                                    <table id="table2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
												<th>Id</th>
												<th>Name</th>
												<th>Image</th>
												
                                            </tr>
                                        </thead>
										<?php 
					while($row2=mysql_fetch_array($qry))
						{
					?>
                                        <tbody>
                                           <tr>
                                               <td><?php echo $row2['id'];?></td>
						<td><?php echo $row2['name']; ?></td><td><img src="user/<?php echo $row2['image']; ?>"  width="20%" height="20%" ></td>
                                            </tr>
                                          </tbody>
                                        <?php
						}
					}
				
					?>
					                    
                                    </table>		
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>