<?php
error_reporting(0);
 date_default_timezone_set('Asia/Kolkata');
		$connect= mysql_connect("localhost","root","")or die("could not connect");
		
		$select=mysql_select_db("krishna_new",$connect) or die("database does not exist");
	?>