  <?php include "layouts/menu.php"; ?>
		<script type="text/javascript">
	  $(function() {
   $("#datepicker").datepicker({ dateFormat: 'dd-mm-yy' });
  });
</script>
   
<script type="text/javascript">
function zp(n){
return n<10?("0"+n):n;
}
function insertDate(t,format){
var now=new Date();
var DD=zp(now.getDate());
var MM=zp(now.getMonth()+1);
var YYYY=now.getFullYear();
format=format.replace(/DD/,DD);
format=format.replace(/MM/,MM);
format=format.replace(/YYYY/,YYYY);
t.value=format;
}
</script>

		   <script>
	function autocomplet() {
	var min_length = 0; // min caracters to display the autocomplete
	var keyword = $('#did').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'ajax_refreshentry.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#country_list_id').show();
				$('#country_list_id').html(data);
			}
		});
	} else {
		$('#country_list_id').hide();
	}
}

// set_item : this function will be executed when we select an item
function set_item(item) {
	// change input value
	$('#did').val(item);
	// hide proposition list
	$('#country_list_id').hide();
}
	</script>

    <script>
  $(function() {
   $("#datepicker1").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker2").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
      <script>
  $(function() {
   $("#datepicker8").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
    <script>
  $(function() {
   $("#datepicker9").datepicker({ dateFormat: 'dd-mm-yy' });
  });
  </script>
   <script type="text/javascript">
function CollapseForm()
{
// Two places to customize:

// Specify the id of the form.
var IDofForm = "form1";

// Specify the id of the div containing the form.
var IDofDivWithForm = "demo";

// This line submits the form. (If Ajax processed, call Ajax function, instead.)
document.getElementById(IDofForm).submit();

// This line collapses the form.
document.getElementById(IDofDivWithForm).style.display = "none";
}
</script>
     
    <?php include "layouts/menu1.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
           <div class="right_col" role="main">
                <!-- Content Header (Page header) -->
              <section class="content-header">
                    <div class="col-lg-6">  	
   
 <?php
$qry=mysql_query("select * from soft ORDER BY id DESC");
$n=mysql_num_rows($qry);
if($n==0)
{
echo "Nothing to Display";
}
else
{
?>
<form name="form8" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
	<div class="col-lg-4">
								 <div class="form-group has-success has-feedback">
    <label for="inputPassword3" >Select Your Company</label>
      <select type="submit" class="form-control" id="inputPassword3" name="ver" value=""><option>Select</option><option>INFOSSEL SOFT SOLUTIONS</option>
	  <?php
	  while($row1=mysql_fetch_array($qry))
{
 	?>
	  <option><?php echo $row1['cname'];?></option>
	  <?php
	  }
	  }
	  ?>
	  </select>
	  
  </div></div>
  		 <div class="col-lg-12"> 
							 
      <button class="btn btn-warning" type="submit" name="ss">Search</button>
</br>
</br>
</div>

  </div>    

 </section>
<?php 
if(isset($_POST['ss']))
{
extract($_POST);
$qry14=mysql_query("select * from task where cname='$ver' AND new=0");
$n4=mysql_num_rows($qry14);
$qry15=mysql_query("select * from task where cname='$ver'AND new=1");
$n5=mysql_num_rows($qry15);
$qry1=mysql_query("select * from task where cname='$ver'");
$n=mysql_num_rows($qry1);
if($n==0)
{
echo "Invalid";
}
else
{

?>
			
  
  			
                    <?php
					$new = 0; 
						?>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                  
                        <div class="col-xs-12"> 
          
                            <div class="box">
                               <!-- /.box-header -->
                                <div class="box-body table-responsive">
                                <div id="mydiv"> <b><?php echo $n4; ?> Pending and <?php echo $n5; ?> Completed Tasks</b>
<input type="button" value="Print" onclick="PrintElem('#mydiv')"  style="margin:20px;"> <div  style="overflow: scroll">
                                    <table id="table2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr class="danger">
                                                <th>S.no</th>
                                                <th>Name</th>
                                                <th colspan="2">E-Date</th>
						<th>Issue Type</th>
						<th>Description</th>
						<th>Assigned to</th>
						<th>Finished By</th>
						<th>Status</th>
						<th>Remark</th>
						<th>Finish Date</th>
						 <th>Edit(Assign)</th>	
 										</tr>
                                        </thead>
										<?php $tg = 0;
					while($row2=mysql_fetch_array($qry1))
						{ $tg++; $nn = $row2['new']; 
					if($nn == 1) { ?>
					
                                        <tbody>
                                           <tr class="success">
                                           <td class="success"><font color="black"><b><?php echo $tg;?></b></font></td>
                                               <td class="success"><font color="black"><b><?php echo $row2['cname'];?></b></font></td>
						<td colspan="2"><font color="black"><b><?php echo $row2['edate']; ?></b></font></td>
						<td><font color="black"><b><?php echo $row2['type']; ?></b></font></td>
						<td><font color="black"><b><?php echo $row2['desc']; ?></b></font></td>
		
						<td><font color="black"><b><?php echo $row2['staff'];?></b></font></td>
						<td><font color="black"><b><?php echo $row2['by'];?></b></font></td>
						
						<td><font color="orange"><b>Completed</b></font></td>
						<td><font color="black"><b><?php echo $row2['remark'];?></b></font></td>
						<td><font color="black"><b><?php echo $row2['fdate'];?></b></font></td>
						<td><a href="utask.php?id=<?php echo $row2['id'];?>">Edit(Assign)</a></td>
					  </tr>
                                          </tbody>
					<?php }
							else { ?>
					
                                        <tbody>
                                           <tr class="warning">
                                           <td><font color="black"><b><?php echo $tg;?></b></font></td>
                                               <td><font color="black"><b><?php echo $row2['cname'];?></b></font></td>
						<td colspan="2"><font color="black"><b><?php echo $row2['edate']; ?></b></font></td>
						<td><font color="black"><b><?php echo $row2['type']; ?></b></font></td>
						<td><font color="black"><b><?php echo $row2['desc']; ?></b></font></td>
		
						<td><font color="black"><b><?php echo $row2['staff'];?></b></font></td>
						<td><font color="black"><b><?php echo $row2['by'];?></b></font></td>
						
						<td><font color="orange"><b>In-Completed</b></font></td>
						<td><font color="black"><b><?php echo $row2['remark'];?></b></font></td>
						<td><font color="black"><b><?php echo $row2['fdate'];?></b></font></td>
						<td><a href="utask.php?id=<?php echo $row2['id'];?>">Edit(Assign)</a></td>
					  </tr>
                                          </tbody>
					<?php }
						}
} }
				
					?>
					                    
                                    </table>		
                                </div>  </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div></div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        <!-- jQuery 2.0.2 -->
       <?php include "layouts/footer.php"; ?>

    </body>
</html>